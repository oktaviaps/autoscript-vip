from bot import *

@app.route("/trial-trojanws", methods=["GET","POST"])
async def trojanwstrial():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if x:
			xjs = eval(x)
			servers = []
			db = get_db()
			quota = db.execute("SELECT quota FROM trojanws").fetchall()
			lim = db.execute("SELECT limcounted FROM trojanws").fetchall()
			cont = db.execute("SELECT counted FROM trojanws").fetchall()
			domain = db.execute("SELECT domain FROM trojanws").fetchall()
			name = db.execute("SELECT buttonname FROM trojanws").fetchall()
			harga = db.execute("SELECT harga FROM trojanws").fetchall()
			print(harga)
			a = 0
			for i, j, v, z, l in zip(domain, name, harga, cont, lim):
				hargaa = "{:,}".format(harga[a][0])
				servers.append({"host":f"{domain[a][0]},{harga[a][0]},{name[a][0]}","name":f"{name[a][0]} - Rp. {hargaa} - Slot {cont[a][0]}/{lim[a][0]} - Quota {quota[a][0]} GB", "price":harga[a][0]})
				a += 1
#			z = db.execute("SELECT buttonname FROM trojanws").fetchall()
			print(servers)
			return render_template("trial-trojanws.html",servers=servers)
		else:
			return redirect("/login")
	elif request.method == "POST":
		x = request.cookies.get("auth")
		if x:
			db = get_db()
			xjs = eval(x)
			telegram = xjs["telegram"]
			saldo = db.execute("SELECT saldo FROM user WHERE member = (?)",(telegram,)).fetchone()[0]
			if int(saldo) <= 0:
				flash(Markup("<strong>Trial Error!</strong><br>0 Balance, Can't Create Account"))
				return redirect("/trial-trojanws")
			else:
				db = get_db()
				user = request.form["username"]
				serverv = request.form.get("server").split(",")
				exp = 1
				buttonname = serverv[2]
				domain = serverv[0]
				quota = db.execute("SELECT quota FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				limitip = db.execute("SELECT limitip FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				lim = db.execute("SELECT limcounted FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				cont = db.execute("SELECT counted FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				serverv = request.form.get("server").split(",")
				if not user:
					flash(Markup("<strong>Trial Error!</strong><br>Invalid Username"))
					return redirect("/trial-trojanws")
				else:
					res = requests.get("http://"+serverv[0]+f":6969/trojan-create?user={user}&exp={exp}&limitip={limitip}&quota={quota}")
					if res.text != "error":
						print(res.text)
						x = res.text.replace('[','').replace(']','').replace('"',
'').split(',')
						print(x)
						today = DT.date.today()
						later = today + DT.timedelta(days=1)
						exp = later.strftime("%Y-%m-%d")
						exp = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(exp),"%Y-%m-%d"))
						date = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(today),"%Y-%m-%d"))
						if len(list(x)) == 2:
							remarks = re.search("#(.*)",x[0]).group(1)
							domain = re.search("@(.*?):",x[0]).group(1)
							uuid = re.search("trojan://(.*?)@",x[0]).group(1)
							path = re.search("path=(.*?)&",x[0]).group(1)
							msg1 = f"""
proxies:
  - name: {remarks}
    server: {domain}
    port: 443
    type: trojan
    password: {uuid}
    skip-cert-verify: true
    sni: bug.com
    network: ws
    ws-opts:
      path: /trojan
      headers:
        Host: {domain}
    udp: true

proxies:
  - name: {remarks}
    server: {domain}
    port: 443
    type: trojan
    password: {uuid}
    skip-cert-verify: true
    sni: bug.com
    network: grpc
    grpc-opts:
      grpc-service-name: trojan
    udp: true
"""
							msg = f"""Trial Trojan WS Account<br>
Domain: {serverv[0]}<br>
Remarks: {remarks}<br>
User {user}<br>
Port TLS: 443<br>
UUID: {uuid}<br>
Path: {path}<br>
Network: Websocket, GRPC<br>
ServiceName: trojan<br>
Expiration: {exp}<br>
<hr><br>
Trojan WS Link:<br>
{x[0].strip('"').replace(' ','')}
<hr><br>
Trojan GRPC Link:<br>
{x[1].strip('"').replace(' ','')}
<hr>
"""
						elif len(list(x)) == 1:
							remarks = re.search("#(.*)",x[0]).group(1)
							domain = re.search("@(.*?):",x[0]).group(1)
							uuid = re.search("trojan://(.*?)@",x[0]).group(1)
							path = re.search("path=(.*?)&",x[0]).group(1)
							msg = f"""Trial Trojan WS Account<br>
Domain: {serverv[0]}<br>
Remarks: {remarks}<br>
User {user}<br>
Port TLS: 443<br>
UUID: {uuid}<br>
Path: {path}<br>
Network: Websocket<br>
Expiration: {exp}<br>
<hr><br>
Trojan WS Link:<br>
{x[0].replace(" ","").strip()}
<hr>"""
#						await Notif("Trial","Trojan",exp,email,salkur,server[0])
						return render_template("trial-trojanws.html",result=msg)

					else:
						flash(Markup("<strong>Trial Error</strong> User Already Exist"))
						return redirect("/trial-trojanws")
	else:
		return "kontoll"




